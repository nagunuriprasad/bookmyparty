import React from 'react';
import './assets/css/PlanningCard.css';
const PlanningCard: React.FC = () => {
  return (
    <>
    <div className="planning-card-container">
    <div className="planning-card">
      <div className="planning-content">
        <h2 className="planning-heading">Planning</h2>
        <p className="planning-extra-text">
          This is some extra information about planning that appears when you hover.
        </p>
      </div>
    </div>

<div className="planning-card">
<div className="planning-content">
  <h2 className="planning-heading">Planning</h2>
  <p className="planning-extra-text">
    This is some extra information about planning that appears when you hover.
  </p>
</div>
</div>

<div className="planning-card">
      <div className="planning-content">
        <h2 className="planning-heading">Planning</h2>
        <p className="planning-extra-text">
          This is some extra information about planning that appears when you hover.
        </p>
      </div>
    </div>
    </div>


<div className="planning-card-container2">
    <div className="planning-card">
      <div className="planning-content">
        <h2 className="planning-heading">Planning</h2>
        <p className="planning-extra-text">
          This is some extra information about planning that appears when you hover.
        </p>
      </div>
    </div>

<div className="planning-card">
<div className="planning-content">
  <h2 className="planning-heading">Planning</h2>
  <p className="planning-extra-text">
    This is some extra information about planning that appears when you hover.
  </p>
</div>
</div>

<div className="planning-card">
      <div className="planning-content">
        <h2 className="planning-heading">Planning</h2>
        <p className="planning-extra-text">
          This is some extra information about planning that appears when you hover.
        </p>
      </div>
    </div>
    </div>
    </>
  );
}

export default PlanningCard;
