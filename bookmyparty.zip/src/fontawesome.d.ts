declare module '@fortawesome/free-solid-svg-icons' {
    export const faArrowRight: any;
    // Add other icons as needed
  }
  